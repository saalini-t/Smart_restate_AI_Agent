# Smart Estate Compass Backend

A comprehensive real estate analysis and forecasting platform that provides intelligent insights for property investment decisions.

## Features

- Property price prediction using machine learning
- Economic trend analysis
- Location intelligence scoring
- Construction planning tools
- PDF report generation
- User authentication and authorization

## Setup

1. Clone the repository
2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Create a `.env` file based on `.env.example`
5. Run the application:
   ```bash
   uvicorn app.main:app --reload
   ```

## API Documentation

Once the application is running, visit:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Testing

Run tests using pytest:
```bash
pytest
```

## Project Structure

```
smart_real_estate_backend/
├── app/                            # Main application directory
│   ├── api/                        # API routes
│   ├── models/                     # Database models
│   ├── schemas/                    # Pydantic models
│   ├── services/                   # Business logic
│   ├── ml/                         # Machine learning models
│   └── utils/                      # Utility functions
├── tests/                          # Test suite
├── requirements.txt                # Project dependencies
└── README.md                       # Project documentation
```

## License

MIT 