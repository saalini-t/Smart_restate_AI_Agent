"""
Smart Estate Compass Backend Application
A comprehensive real estate analysis and forecasting platform
"""

__version__ = "0.1.0" 