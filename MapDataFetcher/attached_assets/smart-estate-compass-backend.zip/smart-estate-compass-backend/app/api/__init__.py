"""
API routes and endpoints for the Smart Estate Compass application
""" 