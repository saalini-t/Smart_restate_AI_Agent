"""
API route handlers for different features
""" 