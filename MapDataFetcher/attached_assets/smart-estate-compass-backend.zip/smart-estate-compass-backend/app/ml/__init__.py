"""
Machine learning models and utilities for the Smart Estate Compass application
""" 