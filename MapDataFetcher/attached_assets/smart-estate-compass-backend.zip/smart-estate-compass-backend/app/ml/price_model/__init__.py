"""
Price prediction models and utilities
""" 