"""
Database models for the Smart Estate Compass application
""" 