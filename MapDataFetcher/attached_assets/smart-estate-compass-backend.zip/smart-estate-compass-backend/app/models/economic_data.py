from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class EconomicData(Base):
    __tablename__ = "economic_data"

    id = Column(Integer, primary_key=True, index=True)
    property_id = Column(Integer, ForeignKey("properties.id"))
    date = Column(DateTime)
    gdp_growth = Column(Float)
    unemployment_rate = Column(Float)
    inflation_rate = Column(Float)
    interest_rate = Column(Float)
    housing_starts = Column(Integer)
    building_permits = Column(Integer)
    
    # Relationships
    property = relationship("Property", back_populates="economic_data") 