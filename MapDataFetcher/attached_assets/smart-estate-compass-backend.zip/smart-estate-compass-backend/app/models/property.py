from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class Property(Base):
    __tablename__ = "properties"

    id = Column(Integer, primary_key=True, index=True)
    address = Column(String, index=True)
    city = Column(String)
    state = Column(String)
    zip_code = Column(String)
    price = Column(Float)
    bedrooms = Column(Integer)
    bathrooms = Column(Float)
    square_footage = Column(Integer)
    year_built = Column(Integer)
    property_type = Column(String)
    listing_date = Column(DateTime)
    last_sold_date = Column(DateTime)
    last_sold_price = Column(Float)
    
    # Relationships
    economic_data = relationship("EconomicData", back_populates="property") 