from pydantic import BaseModel
from datetime import datetime

class EconomicDataBase(BaseModel):
    property_id: int
    date: datetime
    gdp_growth: float
    unemployment_rate: float
    inflation_rate: float
    interest_rate: float
    housing_starts: int
    building_permits: int

class EconomicDataCreate(EconomicDataBase):
    pass

class EconomicData(EconomicDataBase):
    id: int

    class Config:
        from_attributes = True 