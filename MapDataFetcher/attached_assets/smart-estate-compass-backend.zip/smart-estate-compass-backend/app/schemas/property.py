from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class PropertyBase(BaseModel):
    address: str
    city: str
    state: str
    zip_code: str
    price: float
    bedrooms: int
    bathrooms: float
    square_footage: int
    year_built: int
    property_type: str

class PropertyCreate(PropertyBase):
    pass

class Property(PropertyBase):
    id: int
    listing_date: Optional[datetime] = None
    last_sold_date: Optional[datetime] = None
    last_sold_price: Optional[float] = None

    class Config:
        from_attributes = True 