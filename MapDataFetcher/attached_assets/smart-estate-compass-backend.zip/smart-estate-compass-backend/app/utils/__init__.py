"""
Utility functions and helpers for the Smart Estate Compass application
""" 