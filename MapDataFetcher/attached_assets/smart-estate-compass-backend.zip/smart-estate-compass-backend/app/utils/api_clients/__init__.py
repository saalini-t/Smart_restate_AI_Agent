"""
External API client wrappers for various services
""" 