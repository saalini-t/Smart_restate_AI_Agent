import requests
from typing import Dict, Any
from app.config import settings

class TradingEconomicsClient:
    def __init__(self):
        self.api_key = settings.TRADING_ECONOMICS_API_KEY
        self.base_url = "https://api.tradingeconomics.com"

    def get_economic_indicators(self, country: str) -> Dict[str, Any]:
        """
        Fetch economic indicators for a specific country
        """
        endpoint = f"{self.base_url}/country/{country}"
        params = {
            "c": self.api_key,
            "format": "json"
        }
        
        response = requests.get(endpoint, params=params)
        response.raise_for_status()
        
        return response.json() 