
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Calculator } from 'lucide-react';

const ROICalculator = () => {
  const [purchasePrice, setPurchasePrice] = useState(500000);
  const [downPayment, setDownPayment] = useState(100000);
  const [interestRate, setInterestRate] = useState(4.5);
  const [loanTerm, setLoanTerm] = useState(30);
  const [monthlyRent, setMonthlyRent] = useState(2500);
  const [annualPropertyTax, setAnnualPropertyTax] = useState(6000);
  const [annualInsurance, setAnnualInsurance] = useState(1500);
  const [maintenancePercentage, setMaintenancePercentage] = useState(1);
  const [vacancyRate, setVacancyRate] = useState(5);
  const [propertyManagementFee, setPropertyManagementFee] = useState(8);
  const [appreciationRate, setAppreciationRate] = useState(3);
  const [holdingPeriod, setHoldingPeriod] = useState(5);

  // Calculate results
  const calculateResults = () => {
    // Loan amount
    const loanAmount = purchasePrice - downPayment;
    
    // Monthly mortgage payment (principal and interest)
    const monthlyInterestRate = interestRate / 100 / 12;
    const numberOfPayments = loanTerm * 12;
    const monthlyMortgage = loanAmount * 
      (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments)) / 
      (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1);
    
    // Monthly expenses
    const monthlyPropertyTax = annualPropertyTax / 12;
    const monthlyInsurance = annualInsurance / 12;
    const monthlyMaintenance = (purchasePrice * (maintenancePercentage / 100)) / 12;
    const monthlyVacancy = monthlyRent * (vacancyRate / 100);
    const monthlyManagement = monthlyRent * (propertyManagementFee / 100);
    
    const totalMonthlyExpenses = monthlyMortgage + monthlyPropertyTax + 
      monthlyInsurance + monthlyMaintenance + monthlyVacancy + monthlyManagement;
    
    // Monthly cash flow
    const monthlyCashFlow = monthlyRent - totalMonthlyExpenses;
    const annualCashFlow = monthlyCashFlow * 12;
    
    // Cash on cash return
    const initialInvestment = downPayment + (purchasePrice * 0.03); // Assuming 3% closing costs
    const cashOnCashReturn = (annualCashFlow / initialInvestment) * 100;
    
    // Future property value
    const futurePropertyValue = purchasePrice * Math.pow(1 + (appreciationRate / 100), holdingPeriod);
    const equityGain = futurePropertyValue - loanAmount;
    
    // Total ROI
    const totalCashFlow = annualCashFlow * holdingPeriod;
    const totalAppreciation = futurePropertyValue - purchasePrice;
    const totalProfit = totalCashFlow + totalAppreciation;
    const totalROI = (totalProfit / initialInvestment) * 100;
    const annualizedROI = Math.pow(1 + (totalROI / 100), 1 / holdingPeriod) - 1;
    
    return {
      monthlyMortgage: monthlyMortgage.toFixed(2),
      monthlyCashFlow: monthlyCashFlow.toFixed(2),
      annualCashFlow: annualCashFlow.toFixed(2),
      cashOnCashReturn: cashOnCashReturn.toFixed(2),
      futurePropertyValue: futurePropertyValue.toFixed(0),
      equityGain: equityGain.toFixed(0),
      totalROI: totalROI.toFixed(2),
      annualizedROI: (annualizedROI * 100).toFixed(2)
    };
  };

  const results = calculateResults();

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <Calculator className="h-5 w-5 text-primary" />
          Investment ROI Calculator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Property Details</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="purchase-price">Purchase Price ($)</Label>
                  <Input 
                    id="purchase-price" 
                    type="number" 
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="down-payment">Down Payment ($)</Label>
                  <Input 
                    id="down-payment" 
                    type="number" 
                    value={downPayment}
                    onChange={(e) => setDownPayment(Number(e.target.value))}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Financing</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="interest-rate">Interest Rate (%)</Label>
                  <Input 
                    id="interest-rate" 
                    type="number" 
                    step="0.1"
                    value={interestRate}
                    onChange={(e) => setInterestRate(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="loan-term">Loan Term (years)</Label>
                  <Input 
                    id="loan-term" 
                    type="number" 
                    value={loanTerm}
                    onChange={(e) => setLoanTerm(Number(e.target.value))}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Income & Expenses</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="monthly-rent">Monthly Rent ($)</Label>
                  <Input 
                    id="monthly-rent" 
                    type="number" 
                    value={monthlyRent}
                    onChange={(e) => setMonthlyRent(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="property-tax">Annual Property Tax ($)</Label>
                  <Input 
                    id="property-tax" 
                    type="number" 
                    value={annualPropertyTax}
                    onChange={(e) => setAnnualPropertyTax(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="insurance">Annual Insurance ($)</Label>
                  <Input 
                    id="insurance" 
                    type="number" 
                    value={annualInsurance}
                    onChange={(e) => setAnnualInsurance(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maintenance">Maintenance (% of value)</Label>
                  <Input 
                    id="maintenance" 
                    type="number" 
                    step="0.1"
                    value={maintenancePercentage}
                    onChange={(e) => setMaintenancePercentage(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vacancy">Vacancy Rate (%)</Label>
                  <Input 
                    id="vacancy" 
                    type="number" 
                    step="0.1"
                    value={vacancyRate}
                    onChange={(e) => setVacancyRate(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="management">Property Management (%)</Label>
                  <Input 
                    id="management" 
                    type="number" 
                    step="0.1"
                    value={propertyManagementFee}
                    onChange={(e) => setPropertyManagementFee(Number(e.target.value))}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Investment Projection</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="appreciation">Appreciation Rate (%)</Label>
                  <Input 
                    id="appreciation" 
                    type="number" 
                    step="0.1"
                    value={appreciationRate}
                    onChange={(e) => setAppreciationRate(Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="holding-period">Holding Period (years)</Label>
                  <Input 
                    id="holding-period" 
                    type="number" 
                    value={holdingPeriod}
                    onChange={(e) => setHoldingPeriod(Number(e.target.value))}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-sm font-semibold">Results</h3>
            <div className="p-4 border rounded-md bg-muted/30">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Monthly Mortgage</span>
                  <span className="text-sm">${results.monthlyMortgage}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Monthly Cash Flow</span>
                  <span className={`text-sm ${Number(results.monthlyCashFlow) < 0 ? 'text-red-500' : 'text-green-500'}`}>
                    ${results.monthlyCashFlow}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Annual Cash Flow</span>
                  <span className={`text-sm ${Number(results.annualCashFlow) < 0 ? 'text-red-500' : 'text-green-500'}`}>
                    ${results.annualCashFlow}
                  </span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Cash on Cash Return</span>
                  <span className={`text-sm ${Number(results.cashOnCashReturn) < 0 ? 'text-red-500' : 'text-green-500'}`}>
                    {results.cashOnCashReturn}%
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 border rounded-md bg-muted/30">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Future Property Value</span>
                  <span className="text-sm">${results.futurePropertyValue}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Equity Gain</span>
                  <span className="text-sm">${results.equityGain}</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Total ROI ({holdingPeriod} years)</span>
                  <span className="text-sm font-semibold">{results.totalROI}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Annualized ROI</span>
                  <span className="text-sm font-semibold">{results.annualizedROI}%</span>
                </div>
              </div>
            </div>

            <div className="p-4 border rounded-md bg-primary/5">
              <h4 className="text-sm font-medium mb-2">Investment Rating</h4>
              <div className="w-full bg-muted rounded-full h-2.5">
                <div 
                  className={`h-2.5 rounded-full ${
                    Number(results.annualizedROI) > 15 ? 'bg-green-500' :
                    Number(results.annualizedROI) > 10 ? 'bg-emerald-500' :
                    Number(results.annualizedROI) > 5 ? 'bg-blue-500' :
                    Number(results.annualizedROI) > 0 ? 'bg-amber-500' :
                    'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(Number(results.annualizedROI) * 4, 100)}%` }}
                ></div>
              </div>
              <div className="mt-2 text-sm">
                {Number(results.annualizedROI) > 15 ? 'Excellent Investment' :
                Number(results.annualizedROI) > 10 ? 'Very Good Investment' :
                Number(results.annualizedROI) > 5 ? 'Good Investment' :
                Number(results.annualizedROI) > 0 ? 'Fair Investment' :
                'Poor Investment'}
              </div>
            </div>

            <div className="flex justify-center">
              <Button variant="outline">
                Download PDF Report
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ROICalculator;
