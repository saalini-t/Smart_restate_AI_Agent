
import React from 'react';
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface BarChartProps {
  title: string;
  data: any[];
  xKey: string;
  yKeys: { key: string; color: string; name?: string }[];
  className?: string;
  height?: number;
  yAxisFormatter?: (value: number) => string;
  tooltipFormatter?: (value: number) => string;
  gridlines?: boolean;
}

const BarChart = ({
  title,
  data,
  xKey,
  yKeys,
  className,
  height = 350,
  yAxisFormatter = (value) => `${value}`,
  tooltipFormatter = (value) => `${value}`,
  gridlines = true
}: BarChartProps) => {
  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div style={{ height: height }}>
          <ResponsiveContainer width="100%" height="100%">
            <RechartsBarChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              {gridlines && <CartesianGrid strokeDasharray="3 3" stroke="#eee" />}
              <XAxis 
                dataKey={xKey} 
                tick={{ fontSize: 12 }}
                tickLine={{ stroke: '#888' }}
                axisLine={{ stroke: '#888' }}
              />
              <YAxis 
                tickFormatter={yAxisFormatter}
                tick={{ fontSize: 12 }}
                tickLine={{ stroke: '#888' }}
                axisLine={{ stroke: '#888' }}
              />
              <Tooltip 
                formatter={tooltipFormatter}
                contentStyle={{ 
                  backgroundColor: 'rgba(255, 255, 255, 0.9)',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Legend />
              {yKeys.map((barConfig, index) => (
                <Bar
                  key={index}
                  dataKey={barConfig.key}
                  fill={barConfig.color}
                  name={barConfig.name || barConfig.key}
                  radius={[4, 4, 0, 0]}
                />
              ))}
            </RechartsBarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default BarChart;
