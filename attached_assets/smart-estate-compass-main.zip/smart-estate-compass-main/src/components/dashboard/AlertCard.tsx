
import React from 'react';
import { 
  AlertCircle,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface AlertCardProps {
  type: 'opportunity' | 'risk' | 'info';
  message: string;
  urgency: 'low' | 'medium' | 'high';
  className?: string;
}

const AlertCard = ({ type, message, urgency, className }: AlertCardProps) => {
  const getTypeStyles = () => {
    switch (type) {
      case 'opportunity':
        return {
          bg: 'bg-green-50',
          text: 'text-green-800',
          border: 'border-green-200',
          icon: <CheckCircle className="h-5 w-5 text-green-500" />
        };
      case 'risk':
        return {
          bg: 'bg-red-50',
          text: 'text-red-800',
          border: 'border-red-200',
          icon: <AlertTriangle className="h-5 w-5 text-red-500" />
        };
      case 'info':
      default:
        return {
          bg: 'bg-blue-50',
          text: 'text-blue-800',
          border: 'border-blue-200',
          icon: <AlertCircle className="h-5 w-5 text-blue-500" />
        };
    }
  };

  const styles = getTypeStyles();

  return (
    <div className={cn(
      'p-3 rounded-md flex items-start gap-3 border',
      styles.bg,
      styles.text,
      styles.border,
      className
    )}>
      <div className="mt-0.5">{styles.icon}</div>
      <div>
        <p className="text-sm">{message}</p>
        {urgency !== 'low' && (
          <div className="mt-1">
            <span className={cn(
              'text-xs px-2 py-0.5 rounded-full',
              urgency === 'high' ? 'bg-red-200 text-red-800' : 'bg-amber-200 text-amber-800'
            )}>
              {urgency === 'high' ? 'Urgent' : 'Important'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default AlertCard;
