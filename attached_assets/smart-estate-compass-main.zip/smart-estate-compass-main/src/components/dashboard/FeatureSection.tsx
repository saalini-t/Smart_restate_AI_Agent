
import React from 'react';
import ROICalculator from '../calculator/ROICalculator';
import AssistantChatBox from '../chat/AssistantChatBox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calculator, MessageCircle, Bell, FileText } from 'lucide-react';

const FeatureSection = () => {
  return (
    <div className="pt-6">
      <Tabs defaultValue="calculator">
        <TabsList className="mb-4">
          <TabsTrigger value="calculator" className="flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            <span>ROI Calculator</span>
          </TabsTrigger>
          <TabsTrigger value="chat" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            <span>Chat Assistant</span>
          </TabsTrigger>
          <TabsTrigger value="alerts" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span>Alert Preferences</span>
          </TabsTrigger>
          <TabsTrigger value="reports" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span>PDF Reports</span>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="calculator">
          <ROICalculator />
        </TabsContent>
        <TabsContent value="chat">
          <div className="h-[600px]">
            <AssistantChatBox />
          </div>
        </TabsContent>
        <TabsContent value="alerts">
          <div className="p-6 border rounded-md bg-muted/30">
            <h3 className="text-lg font-medium mb-4">Alert Preferences</h3>
            <p className="text-muted-foreground mb-6">Configure your notification preferences for market updates and investment opportunities.</p>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-md">
                  <h4 className="font-medium mb-2">Price Changes</h4>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="price-changes" className="rounded border-gray-300" defaultChecked />
                    <label htmlFor="price-changes" className="text-sm">Alert me about significant price changes</label>
                  </div>
                  <div className="mt-2">
                    <label className="text-sm block mb-1">Threshold (%)</label>
                    <select className="w-full border rounded-md p-1 text-sm bg-background">
                      <option>5%</option>
                      <option>10%</option>
                      <option>15%</option>
                      <option>20%</option>
                    </select>
                  </div>
                </div>
                
                <div className="p-4 border rounded-md">
                  <h4 className="font-medium mb-2">Interest Rate Changes</h4>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="interest-changes" className="rounded border-gray-300" defaultChecked />
                    <label htmlFor="interest-changes" className="text-sm">Alert me about interest rate changes</label>
                  </div>
                  <div className="mt-2">
                    <label className="text-sm block mb-1">Threshold (basis points)</label>
                    <select className="w-full border rounded-md p-1 text-sm bg-background">
                      <option>25</option>
                      <option>50</option>
                      <option>75</option>
                      <option>100</option>
                    </select>
                  </div>
                </div>
                
                <div className="p-4 border rounded-md">
                  <h4 className="font-medium mb-2">New Properties</h4>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="new-properties" className="rounded border-gray-300" defaultChecked />
                    <label htmlFor="new-properties" className="text-sm">Alert me about new properties matching my criteria</label>
                  </div>
                  <div className="mt-2">
                    <label className="text-sm block mb-1">Frequency</label>
                    <select className="w-full border rounded-md p-1 text-sm bg-background">
                      <option>Daily</option>
                      <option>Weekly</option>
                      <option>Immediately</option>
                    </select>
                  </div>
                </div>
                
                <div className="p-4 border rounded-md">
                  <h4 className="font-medium mb-2">Market Reports</h4>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="market-reports" className="rounded border-gray-300" defaultChecked />
                    <label htmlFor="market-reports" className="text-sm">Send me regular market reports</label>
                  </div>
                  <div className="mt-2">
                    <label className="text-sm block mb-1">Frequency</label>
                    <select className="w-full border rounded-md p-1 text-sm bg-background">
                      <option>Weekly</option>
                      <option>Monthly</option>
                      <option>Quarterly</option>
                    </select>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border rounded-md">
                <h4 className="font-medium mb-2">Notification Methods</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <input type="checkbox" id="email-notif" className="rounded border-gray-300" defaultChecked />
                      <label htmlFor="email-notif" className="text-sm">Email</label>
                    </div>
                    <input type="email" placeholder="your@email.com" className="w-full border rounded-md p-1 text-sm bg-background" />
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <input type="checkbox" id="sms-notif" className="rounded border-gray-300" />
                      <label htmlFor="sms-notif" className="text-sm">SMS</label>
                    </div>
                    <input type="tel" placeholder="+1 (555) 123-4567" className="w-full border rounded-md p-1 text-sm bg-background" />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm">
                  Save Preferences
                </button>
              </div>
            </div>
          </div>
        </TabsContent>
        <TabsContent value="reports">
          <div className="p-6 border rounded-md bg-muted/30">
            <h3 className="text-lg font-medium mb-4">PDF Reports</h3>
            <p className="text-muted-foreground mb-6">Generate and download detailed reports for your real estate analysis.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border rounded-md hover:bg-accent/50 cursor-pointer transition-colors">
                <FileText className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium mb-1">Market Analysis</h4>
                <p className="text-sm text-muted-foreground">Comprehensive analysis of market trends and forecasts</p>
                <button className="mt-3 px-3 py-1 bg-primary/10 text-primary rounded text-xs">Generate</button>
              </div>
              
              <div className="p-4 border rounded-md hover:bg-accent/50 cursor-pointer transition-colors">
                <FileText className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium mb-1">Investment Summary</h4>
                <p className="text-sm text-muted-foreground">Detailed ROI projections and investment recommendations</p>
                <button className="mt-3 px-3 py-1 bg-primary/10 text-primary rounded text-xs">Generate</button>
              </div>
              
              <div className="p-4 border rounded-md hover:bg-accent/50 cursor-pointer transition-colors">
                <FileText className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium mb-1">Location Report</h4>
                <p className="text-sm text-muted-foreground">Analysis of neighborhood metrics and location quality</p>
                <button className="mt-3 px-3 py-1 bg-primary/10 text-primary rounded text-xs">Generate</button>
              </div>
              
              <div className="p-4 border rounded-md hover:bg-accent/50 cursor-pointer transition-colors">
                <FileText className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium mb-1">Construction Plan</h4>
                <p className="text-sm text-muted-foreground">Material costs, timeline, and construction recommendations</p>
                <button className="mt-3 px-3 py-1 bg-primary/10 text-primary rounded text-xs">Generate</button>
              </div>
              
              <div className="p-4 border rounded-md hover:bg-accent/50 cursor-pointer transition-colors">
                <FileText className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium mb-1">Comparative Analysis</h4>
                <p className="text-sm text-muted-foreground">Side-by-side comparison of multiple investment options</p>
                <button className="mt-3 px-3 py-1 bg-primary/10 text-primary rounded text-xs">Generate</button>
              </div>
              
              <div className="p-4 border rounded-md hover:bg-accent/50 cursor-pointer transition-colors">
                <FileText className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium mb-1">Custom Report</h4>
                <p className="text-sm text-muted-foreground">Create a tailored report with your selected metrics</p>
                <button className="mt-3 px-3 py-1 bg-primary/10 text-primary rounded text-xs">Generate</button>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FeatureSection;
