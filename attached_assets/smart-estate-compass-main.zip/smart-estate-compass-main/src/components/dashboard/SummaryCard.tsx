
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowDownIcon, ArrowUpIcon } from "lucide-react";
import { cn } from '@/lib/utils';

interface SummaryCardProps {
  title: string;
  value: string;
  change?: string;
  trend?: 'up' | 'down' | 'neutral';
  icon?: React.ReactNode;
  className?: string;
}

const SummaryCard = ({
  title,
  value,
  change,
  trend,
  icon,
  className
}: SummaryCardProps) => {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon && <div className="w-4 h-4 text-muted-foreground">{icon}</div>}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {change && (
          <p className="text-xs text-muted-foreground flex items-center mt-1">
            {trend === 'up' && <ArrowUpIcon className="h-3 w-3 text-green-500 mr-1" />}
            {trend === 'down' && <ArrowDownIcon className="h-3 w-3 text-red-500 mr-1" />}
            <span className={cn(
              trend === 'up' && 'text-green-500',
              trend === 'down' && 'text-red-500'
            )}>
              {change}
            </span>
          </p>
        )}
      </CardContent>
    </Card>
  );
};

export default SummaryCard;
