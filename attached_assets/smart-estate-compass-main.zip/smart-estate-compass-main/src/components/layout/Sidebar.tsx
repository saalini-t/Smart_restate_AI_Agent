
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  BarChart3, 
  Home,
  Map,
  TrendingUp,
  Clock,
  Building,
  Settings
} from "lucide-react";

interface SidebarItemProps {
  icon: React.ElementType;
  label: string;
  href: string;
}

const SidebarItem = ({ icon: Icon, label, href }: SidebarItemProps) => {
  const { pathname } = useLocation();
  const isActive = pathname === href;
  
  return (
    <Button
      variant="ghost"
      className={cn(
        "w-full justify-start gap-2 pl-2 mb-1",
        isActive ? "bg-accent text-accent-foreground" : "hover:bg-accent hover:text-accent-foreground"
      )}
      asChild
    >
      <Link to={href}>
        <Icon className="h-5 w-5" />
        <span>{label}</span>
      </Link>
    </Button>
  );
};

const Sidebar = () => {
  return (
    <div className="hidden md:flex h-screen w-64 flex-col fixed inset-y-0 z-50 bg-background border-r">
      <div className="px-4 py-6">
        <div className="flex items-center gap-2 text-lg font-semibold">
          <TrendingUp className="h-6 w-6 text-primary" />
          <span>Smart Estate AI</span>
        </div>
      </div>
      <ScrollArea className="flex-1 px-2">
        <div className="space-y-4 pb-4">
          <div className="py-2">
            <h3 className="px-4 text-xs font-semibold text-muted-foreground mb-2">
              DASHBOARD
            </h3>
            <div className="space-y-1">
              <SidebarItem icon={Home} label="Overview" href="/" />
            </div>
          </div>
          <div className="py-2">
            <h3 className="px-4 text-xs font-semibold text-muted-foreground mb-2">
              ANALYSIS
            </h3>
            <div className="space-y-1">
              <SidebarItem icon={BarChart3} label="Economic Trends" href="/economic-trends" />
              <SidebarItem icon={TrendingUp} label="Price Forecasting" href="/price-forecasting" />
              <SidebarItem icon={Map} label="Location Intelligence" href="/location-intelligence" />
              <SidebarItem icon={Clock} label="Investment Timing" href="/investment-timing" />
              <SidebarItem icon={Building} label="Construction Planner" href="/construction-planner" />
            </div>
          </div>
          <div className="py-2">
            <h3 className="px-4 text-xs font-semibold text-muted-foreground mb-2">
              SETTINGS
            </h3>
            <div className="space-y-1">
              <SidebarItem icon={Settings} label="Preferences" href="/settings" />
            </div>
          </div>
        </div>
      </ScrollArea>
      <div className="px-3 py-2 border-t hidden md:block">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center">
            <span className="font-semibold">AI</span>
          </div>
          <div>
            <p className="text-foreground font-medium">Smart Estate</p>
            <p className="text-xs">AI-powered insights</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
