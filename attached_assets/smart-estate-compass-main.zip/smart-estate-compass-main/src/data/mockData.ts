
// Mock data for the application

// Economic Trends Data
export const economicTrendsData = {
  inflation: [
    { month: 'Jan', rate: 2.5 },
    { month: 'Feb', rate: 2.6 },
    { month: 'Mar', rate: 2.8 },
    { month: 'Apr', rate: 3.1 },
    { month: 'May', rate: 3.3 },
    { month: 'Jun', rate: 3.5 },
    { month: 'Jul', rate: 3.2 },
    { month: 'Aug', rate: 3.0 },
    { month: 'Sep', rate: 2.8 },
    { month: 'Oct', rate: 2.5 },
    { month: 'Nov', rate: 2.4 },
    { month: 'Dec', rate: 2.3 },
  ],
  gdpGrowth: [
    { quarter: 'Q1 2023', rate: 2.1 },
    { quarter: 'Q2 2023', rate: 2.4 },
    { quarter: 'Q3 2023', rate: 2.7 },
    { quarter: 'Q4 2023', rate: 2.9 },
    { quarter: 'Q1 2024', rate: 3.1 },
    { quarter: 'Q2 2024', rate: 3.0 },
    { quarter: 'Q3 2024', rate: 2.8 },
    { quarter: 'Q4 2024', rate: 2.6 },
  ],
  interestRates: [
    { month: 'Jan', rate: 4.5 },
    { month: 'Feb', rate: 4.5 },
    { month: 'Mar', rate: 4.75 },
    { month: 'Apr', rate: 4.75 },
    { month: 'May', rate: 5.0 },
    { month: 'Jun', rate: 5.0 },
    { month: 'Jul', rate: 5.25 },
    { month: 'Aug', rate: 5.25 },
    { month: 'Sep', rate: 5.0 },
    { month: 'Oct', rate: 5.0 },
    { month: 'Nov', rate: 4.75 },
    { month: 'Dec', rate: 4.5 },
  ],
  forecast: {
    inflationForecast: [
      { month: 'Jan', actual: 2.3, predicted: null },
      { month: 'Feb', actual: 2.2, predicted: null },
      { month: 'Mar', actual: 2.1, predicted: null },
      { month: 'Apr', actual: null, predicted: 2.0 },
      { month: 'May', actual: null, predicted: 1.9 },
      { month: 'Jun', actual: null, predicted: 1.8 },
    ],
    gdpForecast: [
      { quarter: 'Q1 2024', actual: 3.1, predicted: null },
      { quarter: 'Q2 2024', actual: null, predicted: 3.2 },
      { quarter: 'Q3 2024', actual: null, predicted: 3.4 },
      { quarter: 'Q4 2024', actual: null, predicted: 3.5 },
    ],
    interestRateForecast: [
      { month: 'Jan', actual: 4.5, predicted: null },
      { month: 'Feb', actual: 4.25, predicted: null },
      { month: 'Mar', actual: 4.0, predicted: null },
      { month: 'Apr', actual: null, predicted: 3.75 },
      { month: 'May', actual: null, predicted: 3.5 },
      { month: 'Jun', actual: null, predicted: 3.25 },
    ],
  },
  marketStatus: "Buyer's Market", // or "Seller's Market"
  confidenceScore: 87
};

// Property Price Data
export const propertyPriceData = {
  historicalPrices: [
    { year: 2018, price: 320000 },
    { year: 2019, price: 340000 },
    { year: 2020, price: 355000 },
    { year: 2021, price: 380000 },
    { year: 2022, price: 420000 },
    { year: 2023, price: 450000 },
  ],
  forecastPrices: [
    { year: 2023, price: 450000 },
    { year: 2024, price: 472000 },
    { year: 2025, price: 490000 },
    { year: 2026, price: 515000 },
    { year: 2027, price: 535000 },
  ],
  pricePerSqft: {
    current: 305,
    predicted: 325,
    cityAverage: 290
  },
  marketAssessment: "Slightly Overvalued",
  investmentPotential: "Moderate"
};

// Location Intelligence Data
export const locationData = {
  address: "123 Main Street, Cityville, ST 12345",
  coordinates: { lat: 40.7128, lng: -74.0060 },
  locationScores: {
    overall: 82,
    education: 88,
    healthcare: 76,
    transportation: 85,
    safety: 79,
    amenities: 83,
    environment: 80
  },
  nearbyFacilities: {
    schools: [
      { name: "Cityville Elementary", distance: 0.8, rating: 8.5 },
      { name: "Westside Middle School", distance: 1.2, rating: 7.9 },
      { name: "Central High School", distance: 1.5, rating: 8.2 }
    ],
    hospitals: [
      { name: "Cityville General Hospital", distance: 2.3, rating: 4.2 },
      { name: "Medical Center", distance: 3.1, rating: 4.5 }
    ],
    parks: [
      { name: "Riverside Park", distance: 0.6, size: "Large" },
      { name: "Central Park", distance: 1.3, size: "Medium" }
    ],
    publicTransport: [
      { type: "Bus Stop", name: "Main Street", distance: 0.2 },
      { type: "Subway", name: "Downtown Station", distance: 0.8 }
    ]
  },
  crimeRate: { value: "Low", trend: "Decreasing" }
};

// Investment Timing Data
export const investmentTimingData = {
  marketCycle: {
    currentPhase: "Early Recovery",
    nextPhase: "Expansion",
    estimate: "Q3 2024"
  },
  marketMomentum: [
    { month: "Jan", value: 65 },
    { month: "Feb", value: 68 },
    { month: "Mar", value: 72 },
    { month: "Apr", value: 75 },
    { month: "May", value: 79 },
    { month: "Jun", value: 82 },
    { month: "Jul", value: 85 },
    { month: "Aug", value: 88 },
    { month: "Sep", value: 86 },
    { month: "Oct", value: 83 },
    { month: "Nov", value: 80 },
    { month: "Dec", value: 78 }
  ],
  investmentScenarios: {
    buy: {
      now: {
        roi5Year: 28.5,
        riskLevel: "Medium",
        confidenceScore: 72
      },
      wait3Months: {
        roi5Year: 31.2,
        riskLevel: "Medium-Low",
        confidenceScore: 78
      },
      wait6Months: {
        roi5Year: 26.8,
        riskLevel: "Medium-High",
        confidenceScore: 68
      }
    },
    sell: {
      now: {
        profit: 85000,
        marketTiming: "Suboptimal",
        confidenceScore: 65
      },
      wait3Months: {
        profit: 92000,
        marketTiming: "Favorable",
        confidenceScore: 77
      },
      wait6Months: {
        profit: 98000,
        marketTiming: "Optimal",
        confidenceScore: 83
      }
    }
  },
  recommendation: "Wait 3 Months"
};

// Construction Planning Data
export const constructionData = {
  materialPrices: {
    steel: [
      { month: "Jan", price: 680 },
      { month: "Feb", price: 695 },
      { month: "Mar", price: 710 },
      { month: "Apr", price: 705 },
      { month: "May", price: 690 },
      { month: "Jun", price: 685 },
      { month: "Jul", price: 675 },
      { month: "Aug", price: 670 },
      { month: "Sep", price: 665 },
      { month: "Oct", price: 660 },
      { month: "Nov", price: 655 },
      { month: "Dec", price: 650 }
    ],
    cement: [
      { month: "Jan", price: 110 },
      { month: "Feb", price: 115 },
      { month: "Mar", price: 118 },
      { month: "Apr", price: 120 },
      { month: "May", price: 122 },
      { month: "Jun", price: 120 },
      { month: "Jul", price: 118 },
      { month: "Aug", price: 115 },
      { month: "Sep", price: 112 },
      { month: "Oct", price: 110 },
      { month: "Nov", price: 108 },
      { month: "Dec", price: 105 }
    ],
    lumber: [
      { month: "Jan", price: 380 },
      { month: "Feb", price: 390 },
      { month: "Mar", price: 410 },
      { month: "Apr", price: 425 },
      { month: "May", price: 435 },
      { month: "Jun", price: 445 },
      { month: "Jul", price: 430 },
      { month: "Aug", price: 415 },
      { month: "Sep", price: 400 },
      { month: "Oct", price: 385 },
      { month: "Nov", price: 375 },
      { month: "Dec", price: 370 }
    ]
  },
  weatherForecast: [
    { month: "Jan", precipitation: "High", temperature: "Low", constructionSuitability: "Poor" },
    { month: "Feb", precipitation: "High", temperature: "Low", constructionSuitability: "Poor" },
    { month: "Mar", precipitation: "Medium", temperature: "Low", constructionSuitability: "Fair" },
    { month: "Apr", precipitation: "Medium", temperature: "Moderate", constructionSuitability: "Good" },
    { month: "May", precipitation: "Low", temperature: "Moderate", constructionSuitability: "Excellent" },
    { month: "Jun", precipitation: "Low", temperature: "High", constructionSuitability: "Excellent" },
    { month: "Jul", precipitation: "Low", temperature: "High", constructionSuitability: "Good" },
    { month: "Aug", precipitation: "Low", temperature: "High", constructionSuitability: "Good" },
    { month: "Sep", precipitation: "Low", temperature: "Moderate", constructionSuitability: "Excellent" },
    { month: "Oct", precipitation: "Medium", temperature: "Moderate", constructionSuitability: "Good" },
    { month: "Nov", precipitation: "Medium", temperature: "Low", constructionSuitability: "Fair" },
    { month: "Dec", precipitation: "High", temperature: "Low", constructionSuitability: "Poor" }
  ],
  laborCosts: {
    current: 42,
    trend: "Increasing",
    forecast: [
      { quarter: "Q1", cost: 42 },
      { quarter: "Q2", cost: 43 },
      { quarter: "Q3", cost: 44 },
      { quarter: "Q4", cost: 45 }
    ]
  },
  optimalStartDate: "May 2024",
  constructionDuration: "8 months",
  riskFactors: [
    { factor: "Material Price Volatility", risk: "Medium" },
    { factor: "Labor Availability", risk: "High" },
    { factor: "Permit Delays", risk: "Low" },
    { factor: "Weather Disruptions", risk: "Medium" }
  ]
};

// Dashboard Summary Data
export const dashboardSummary = {
  marketHealth: {
    status: "Healthy",
    trend: "Improving",
    confidenceScore: 82,
  },
  keyMetrics: [
    {
      title: "Property Appreciation",
      value: "4.8%",
      change: "+0.3%",
      trend: "up",
    },
    {
      title: "Market Affordability",
      value: "68/100",
      change: "-2",
      trend: "down",
    },
    {
      title: "Rental Yield",
      value: "5.2%",
      change: "+0.1%",
      trend: "up",
    },
    {
      title: "Mortgage Rate",
      value: "4.5%",
      change: "-0.25%",
      trend: "down",
    },
  ],
  topInvestmentAreas: [
    {
      name: "Downtown",
      growth: "7.2%",
      confidence: "High",
    },
    {
      name: "Westside",
      growth: "6.8%",
      confidence: "Medium",
    },
    {
      name: "North Hills",
      growth: "5.9%",
      confidence: "High",
    },
  ],
  alerts: [
    {
      type: "opportunity",
      message: "Interest rates expected to drop by Q3 2024 - good time for financing",
      urgency: "medium",
    },
    {
      type: "risk",
      message: "Construction material prices rising in Central Area",
      urgency: "high",
    },
    {
      type: "info",
      message: "New zoning laws affecting property development in Eastside",
      urgency: "low",
    },
  ],
};

// Default property types for selection
export const propertyTypes = [
  "Single Family Home",
  "Condominium",
  "Townhouse",
  "Multi-Family",
  "Commercial",
  "Land",
  "Industrial",
];

// Default cities for selection
export const cities = [
  "New York, NY",
  "Los Angeles, CA",
  "Chicago, IL",
  "Houston, TX",
  "Phoenix, AZ",
  "Philadelphia, PA",
  "San Antonio, TX",
  "San Diego, CA",
  "Dallas, TX",
  "San Jose, CA",
];
