
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import LineChart from '@/components/charts/LineChart';
import { constructionData } from '@/data/mockData';
import { Cloud, Loader2, AlertTriangle, CalendarDays, Clock, Sun, Building } from 'lucide-react';

const ConstructionPlanner = () => {
  const weatherColors = {
    Poor: 'bg-red-500',
    Fair: 'bg-amber-500',
    Good: 'bg-blue-500',
    Excellent: 'bg-green-500'
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Construction Planner</h1>
        <p className="text-muted-foreground mt-2">
          Plan your construction project with insights on material costs, labor availability, and seasonal factors.
        </p>
      </div>

      <div className="grid gap-6 grid-cols-1 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Material Price Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <LineChart
              title=""
              data={constructionData.materialPrices.steel}
              xKey="month"
              yKeys={[
                { key: 'price', color: '#6E6E6E', name: 'Steel ($/ton)' },
              ]}
              yAxisFormatter={(value) => `$${value}`}
              tooltipFormatter={(value) => `$${value}`}
              height={300}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Optimal Timeline</CardTitle>
            <CalendarDays className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center py-4">
              <div className="w-20 h-20 rounded-full bg-green-50 flex items-center justify-center mb-4">
                <Clock className="h-10 w-10 text-green-500" />
              </div>
              
              <div className="text-center mb-6">
                <h3 className="text-lg font-bold mb-1">{constructionData.optimalStartDate}</h3>
                <p className="text-sm text-muted-foreground">Best time to begin construction</p>
              </div>
              
              <div className="w-full space-y-4">
                <div className="p-3 border rounded-md">
                  <h4 className="text-sm font-medium mb-1">Duration Estimate</h4>
                  <p className="text-sm">{constructionData.constructionDuration}</p>
                </div>
                
                <div className="p-3 border rounded-md flex gap-3">
                  <Sun className="h-5 w-5 text-amber-500" />
                  <div>
                    <h4 className="text-sm font-medium">Weather Advantage</h4>
                    <p className="text-xs text-muted-foreground">
                      Optimal weather conditions for concrete pouring and exterior work.
                    </p>
                  </div>
                </div>
                
                <div className="p-3 border rounded-md flex gap-3">
                  <Building className="h-5 w-5 text-blue-500" />
                  <div>
                    <h4 className="text-sm font-medium">Labor Availability</h4>
                    <p className="text-xs text-muted-foreground">
                      Better contractor availability before summer peak season.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 grid-cols-1 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Material Price Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-medium mb-2">Steel ($/ton)</h3>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>Current Price</span>
                  <span className="font-semibold">${constructionData.materialPrices.steel[5].price}</span>
                </div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>3-Month Forecast</span>
                  <span className="font-semibold text-green-500">${constructionData.materialPrices.steel[8].price} (-4.0%)</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>6-Month Forecast</span>
                  <span className="font-semibold text-green-500">${constructionData.materialPrices.steel[11].price} (-5.8%)</span>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Cement ($/bag)</h3>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>Current Price</span>
                  <span className="font-semibold">${constructionData.materialPrices.cement[5].price}</span>
                </div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>3-Month Forecast</span>
                  <span className="font-semibold text-green-500">${constructionData.materialPrices.cement[8].price} (-6.7%)</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>6-Month Forecast</span>
                  <span className="font-semibold text-green-500">${constructionData.materialPrices.cement[11].price} (-12.5%)</span>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Lumber ($/1000 bd. ft.)</h3>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>Current Price</span>
                  <span className="font-semibold">${constructionData.materialPrices.lumber[5].price}</span>
                </div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>3-Month Forecast</span>
                  <span className="font-semibold text-red-500">${constructionData.materialPrices.lumber[8].price} (-10.1%)</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>6-Month Forecast</span>
                  <span className="font-semibold text-green-500">${constructionData.materialPrices.lumber[11].price} (-16.9%)</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <Cloud className="h-5 w-5 text-blue-500" />
              Seasonal Suitability
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {constructionData.weatherForecast.map((month, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-20 text-sm font-medium">{month.month}</div>
                  <div 
                    className={`h-8 flex-1 rounded-md flex items-center justify-center text-xs font-medium text-white 
                      ${month.constructionSuitability === 'Poor' ? 'bg-red-500' : 
                      month.constructionSuitability === 'Fair' ? 'bg-amber-500' : 
                      month.constructionSuitability === 'Good' ? 'bg-blue-500' : 
                      'bg-green-500'}`}
                  >
                    {month.constructionSuitability}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Labor Costs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="flex flex-col items-center p-4 border rounded-md">
                <div className="text-3xl font-bold text-primary mb-2">${constructionData.laborCosts.current}</div>
                <p className="text-sm text-muted-foreground">Average hourly rate (USD)</p>
                <div className="flex items-center mt-2 text-sm font-medium text-amber-500 gap-1">
                  <Loader2 className="h-4 w-4" />
                  <span>{constructionData.laborCosts.trend}</span>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-3">Quarterly Forecast</h3>
                <div className="space-y-2">
                  {constructionData.laborCosts.forecast.map((item, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-14 text-sm font-medium">{item.quarter}</div>
                      <div className="h-8 flex-1 bg-muted rounded-md relative">
                        <div 
                          className="absolute left-0 top-0 h-full bg-blue-500 rounded-md flex items-center justify-end pr-2 text-xs font-medium text-white"
                          style={{ width: `${(item.cost / 50) * 100}%` }}
                        >
                          ${item.cost}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Risk Assessment
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
            {constructionData.riskFactors.map((risk, index) => (
              <div key={index} className="p-4 border rounded-md">
                <h3 className="text-sm font-medium mb-2">{risk.factor}</h3>
                <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                  ${risk.risk === 'Low' ? 'bg-green-100 text-green-800' : 
                  risk.risk === 'Medium' ? 'bg-amber-100 text-amber-800' : 
                  'bg-red-100 text-red-800'}`}
                >
                  {risk.risk} Risk
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {risk.factor === 'Material Price Volatility' && 'Steel and lumber prices expected to decrease over the next 6 months.'}
                  {risk.factor === 'Labor Availability' && 'Skilled labor shortage may affect timelines and costs.'}
                  {risk.factor === 'Permit Delays' && 'Current processing times for permits are within normal ranges.'}
                  {risk.factor === 'Weather Disruptions' && 'Spring months have lower risk of severe weather delays.'}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ConstructionPlanner;
