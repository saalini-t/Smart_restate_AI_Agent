
import React from 'react';
import SummaryCard from '@/components/dashboard/SummaryCard';
import AlertCard from '@/components/dashboard/AlertCard';
import FeatureSection from '@/components/dashboard/FeatureSection';
import LineChart from '@/components/charts/LineChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3, MapPin, TrendingUp, ArrowDownRight, ArrowUpRight, Bell } from 'lucide-react';
import { dashboardSummary, economicTrendsData, propertyPriceData } from '@/data/mockData';

const Dashboard = () => {
  // Prepare chart data for the dashboard
  const priceAppreciationData = [...propertyPriceData.historicalPrices.slice(-6), ...propertyPriceData.forecastPrices.slice(1)];
  
  // Filter to relevant economic data for the dashboard
  const recentEconomicData = economicTrendsData.inflation.slice(-6);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Your real estate intelligence overview and market insights.
        </p>
      </div>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
        {dashboardSummary.keyMetrics.map((metric, index) => (
          <SummaryCard
            key={index}
            title={metric.title}
            value={metric.value}
            change={metric.change}
            trend={metric.trend as 'up' | 'down'}
            className="h-full"
          />
        ))}
      </div>

      <div className="grid gap-4 grid-cols-1 lg:grid-cols-2">
        <LineChart
          title="Property Price Trends"
          data={priceAppreciationData}
          xKey="year"
          yKeys={[
            { key: 'price', color: '#8B5CF6', name: 'Price ($)' }
          ]}
          yAxisFormatter={(value) => `$${value / 1000}k`}
          tooltipFormatter={(value) => `$${value.toLocaleString()}`}
          height={300}
        />
        
        <LineChart
          title="Economic Indicators"
          data={recentEconomicData}
          xKey="month"
          yKeys={[
            { key: 'rate', color: '#F97316', name: 'Inflation Rate (%)' }
          ]}
          yAxisFormatter={(value) => `${value}%`}
          tooltipFormatter={(value) => `${value}%`}
          height={300}
        />
      </div>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Market Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Status</span>
                <span className="text-sm font-semibold">{dashboardSummary.marketHealth.status}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Trend</span>
                <span className="text-sm font-semibold flex items-center">
                  {dashboardSummary.marketHealth.trend === "Improving" ? (
                    <ArrowUpRight className="h-4 w-4 text-green-500 mr-1" />
                  ) : (
                    <ArrowDownRight className="h-4 w-4 text-red-500 mr-1" />
                  )}
                  {dashboardSummary.marketHealth.trend}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Confidence</span>
                <span className="text-sm font-semibold">{dashboardSummary.marketHealth.confidenceScore}/100</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Market Type</span>
                <span className="text-sm font-semibold">{economicTrendsData.marketStatus}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Top Investment Areas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-3">
              {dashboardSummary.topInvestmentAreas.map((area, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary font-semibold text-xs">
                      {index + 1}
                    </div>
                    <span className="text-sm font-medium">{area.name}</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-sm font-semibold text-green-500">{area.growth}</span>
                    <span className="text-xs text-muted-foreground">{area.confidence}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              Market Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-3">
              {dashboardSummary.alerts.map((alert, index) => (
                <AlertCard
                  key={index}
                  type={alert.type as 'opportunity' | 'risk' | 'info'}
                  message={alert.message}
                  urgency={alert.urgency as 'low' | 'medium' | 'high'}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <FeatureSection />
    </div>
  );
};

export default Dashboard;
