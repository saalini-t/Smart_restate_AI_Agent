
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import LineChart from '@/components/charts/LineChart';
import { economicTrendsData } from '@/data/mockData';
import { ArrowDownIcon, ArrowUpIcon, BarChart3 } from 'lucide-react';

const EconomicTrends = () => {
  // Prepare forecast data points that combine actual and predicted values
  const inflationForecast = economicTrendsData.forecast.inflationForecast.map(point => ({
    month: point.month,
    actual: point.actual,
    predicted: point.predicted
  }));

  const interestRateForecast = economicTrendsData.forecast.interestRateForecast.map(point => ({
    month: point.month,
    actual: point.actual,
    predicted: point.predicted
  }));

  const gdpForecast = economicTrendsData.forecast.gdpForecast.map(point => ({
    quarter: point.quarter,
    actual: point.actual,
    predicted: point.predicted
  }));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Economic Trend Monitoring</h1>
        <p className="text-muted-foreground mt-2">
          Track key economic indicators that impact real estate markets.
        </p>
      </div>

      <div className="grid gap-6 grid-cols-1 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-blue-500" />
              Market Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between py-4">
              <div>
                <div className="text-2xl font-bold">{economicTrendsData.marketStatus}</div>
                <div className="text-sm text-muted-foreground">Current market phase</div>
              </div>
              {economicTrendsData.marketStatus.includes("Buyer") ? (
                <ArrowDownIcon className="h-8 w-8 text-blue-500" />
              ) : (
                <ArrowUpIcon className="h-8 w-8 text-red-500" />
              )}
            </div>
            <div className="mt-2 text-sm">
              <div className="flex justify-between mb-1">
                <span>Confidence Score</span>
                <span className="font-medium">{economicTrendsData.confidenceScore}/100</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full" 
                  style={{ width: `${economicTrendsData.confidenceScore}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Key Takeaways</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 text-blue-700 p-2 rounded-full">
                  <ArrowDownIcon className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold">Interest Rates Trending Down</h4>
                  <p className="text-sm text-muted-foreground">
                    Mortgage rates expected to decrease by 0.75% over the next 6 months.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-amber-100 text-amber-700 p-2 rounded-full">
                  <BarChart3 className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold">Inflation Stabilizing</h4>
                  <p className="text-sm text-muted-foreground">
                    Inflation expected to remain stable around 2.0-2.2% for the next quarter.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-green-100 text-green-700 p-2 rounded-full">
                  <ArrowUpIcon className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold">GDP Growth Positive</h4>
                  <p className="text-sm text-muted-foreground">
                    Economic growth projected at 3.2-3.5% for the remainder of the year.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
        <LineChart
          title="Inflation Rate Trends (%)"
          data={economicTrendsData.inflation}
          xKey="month"
          yKeys={[{ key: 'rate', color: '#F97316', name: 'Inflation Rate' }]}
          yAxisFormatter={(value) => `${value}%`}
          tooltipFormatter={(value) => `${value}%`}
        />
        
        <LineChart
          title="Interest Rate Trends (%)"
          data={economicTrendsData.interestRates}
          xKey="month"
          yKeys={[{ key: 'rate', color: '#8B5CF6', name: 'Interest Rate' }]}
          yAxisFormatter={(value) => `${value}%`}
          tooltipFormatter={(value) => `${value}%`}
        />
      </div>

      <div>
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg font-medium">GDP Growth Rate (%)</CardTitle>
          </CardHeader>
          <CardContent>
            <LineChart
              title=""
              data={economicTrendsData.gdpGrowth}
              xKey="quarter"
              yKeys={[{ key: 'rate', color: '#10B981', name: 'GDP Growth Rate' }]}
              yAxisFormatter={(value) => `${value}%`}
              tooltipFormatter={(value) => `${value}%`}
              height={300}
            />
          </CardContent>
        </Card>
      </div>

      <div>
        <h2 className="text-2xl font-bold tracking-tight mb-4">Economic Forecasts</h2>
        <div className="grid gap-6 grid-cols-1 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Inflation Forecast</CardTitle>
            </CardHeader>
            <CardContent>
              <LineChart
                title=""
                data={inflationForecast}
                xKey="month"
                yKeys={[
                  { key: 'actual', color: '#F97316', name: 'Actual' },
                  { key: 'predicted', color: '#F97316', name: 'Predicted' }
                ]}
                yAxisFormatter={(value) => value ? `${value}%` : ''}
                tooltipFormatter={(value) => value ? `${value}%` : 'N/A'}
                height={250}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Interest Rate Forecast</CardTitle>
            </CardHeader>
            <CardContent>
              <LineChart
                title=""
                data={interestRateForecast}
                xKey="month"
                yKeys={[
                  { key: 'actual', color: '#8B5CF6', name: 'Actual' },
                  { key: 'predicted', color: '#8B5CF6', name: 'Predicted' }
                ]}
                yAxisFormatter={(value) => value ? `${value}%` : ''}
                tooltipFormatter={(value) => value ? `${value}%` : 'N/A'}
                height={250}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">GDP Growth Forecast</CardTitle>
            </CardHeader>
            <CardContent>
              <LineChart
                title=""
                data={gdpForecast}
                xKey="quarter"
                yKeys={[
                  { key: 'actual', color: '#10B981', name: 'Actual' },
                  { key: 'predicted', color: '#10B981', name: 'Predicted' }
                ]}
                yAxisFormatter={(value) => value ? `${value}%` : ''}
                tooltipFormatter={(value) => value ? `${value}%` : 'N/A'}
                height={250}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default EconomicTrends;
