
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import LineChart from '@/components/charts/LineChart';
import BarChart from '@/components/charts/BarChart';
import { investmentTimingData } from '@/data/mockData';
import { ArrowUpRight, Clock, AlertCircle, TrendingUp, CalendarDays } from 'lucide-react';

const InvestmentTiming = () => {
  const [investmentGoal, setInvestmentGoal] = useState('buy');
  const [holdingPeriod, setHoldingPeriod] = useState('5');

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Investment Timing Assistant</h1>
        <p className="text-muted-foreground mt-2">
          Determine optimal timing for buying, selling, or developing real estate based on market cycles.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-medium">Investment Goals</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
            <div className="space-y-2">
              <label className="text-sm font-medium">Investment Goal</label>
              <Select value={investmentGoal} onValueChange={setInvestmentGoal}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select your goal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="buy">Buy to Hold</SelectItem>
                  <SelectItem value="flip">Buy to Flip</SelectItem>
                  <SelectItem value="develop">Develop Property</SelectItem>
                  <SelectItem value="sell">Sell Property</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Holding Period (Years)</label>
              <Select value={holdingPeriod} onValueChange={setHoldingPeriod}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select holding period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 year</SelectItem>
                  <SelectItem value="3">3 years</SelectItem>
                  <SelectItem value="5">5 years</SelectItem>
                  <SelectItem value="10">10 years</SelectItem>
                  <SelectItem value="15">15+ years</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 grid-cols-1 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Market Momentum</CardTitle>
          </CardHeader>
          <CardContent>
            <LineChart
              title=""
              data={investmentTimingData.marketMomentum}
              xKey="month"
              yKeys={[{ key: 'value', color: '#8B5CF6', name: 'Market Momentum' }]}
              yAxisFormatter={(value) => `${value}`}
              tooltipFormatter={(value) => `${value}/100`}
              height={300}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Market Cycle</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center text-center">
              <div className="relative w-40 h-40">
                <div className="absolute inset-0 rounded-full border-4 border-muted overflow-hidden">
                  <div className="absolute w-full h-full">
                    <div className="absolute top-0 left-0 w-1/2 h-1/2 bg-blue-100 flex items-center justify-center text-xs font-medium text-blue-700">
                      Recovery
                    </div>
                    <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-green-100 flex items-center justify-center text-xs font-medium text-green-700">
                      Expansion
                    </div>
                    <div className="absolute bottom-0 right-0 w-1/2 h-1/2 bg-amber-100 flex items-center justify-center text-xs font-medium text-amber-700">
                      Contraction
                    </div>
                    <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-red-100 flex items-center justify-center text-xs font-medium text-red-700">
                      Recession
                    </div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="h-16 w-16 rounded-full bg-background flex items-center justify-center shadow-md">
                      <ArrowUpRight 
                        className="h-8 w-8 text-primary"
                        style={{ transform: 'rotate(45deg)' }} 
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 space-y-2">
                <p className="text-sm font-medium">Current Phase: <span className="text-blue-600">{investmentTimingData.marketCycle.currentPhase}</span></p>
                <p className="text-sm font-medium">Next Phase: <span className="text-green-600">{investmentTimingData.marketCycle.nextPhase}</span></p>
                <p className="text-sm font-medium">Estimated Transition: <span>{investmentTimingData.marketCycle.estimate}</span></p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 grid-cols-1 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Investment Scenarios</CardTitle>
            <TrendingUp className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            {investmentGoal === 'buy' && (
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium text-sm">Projected 5-Year ROI for Buy Scenarios</h3>
                  <BarChart
                    title=""
                    data={[
                      { scenario: 'Buy Now', roi: investmentTimingData.investmentScenarios.buy.now.roi5Year },
                      { scenario: 'Wait 3 Months', roi: investmentTimingData.investmentScenarios.buy.wait3Months.roi5Year },
                      { scenario: 'Wait 6 Months', roi: investmentTimingData.investmentScenarios.buy.wait6Months.roi5Year }
                    ]}
                    xKey="scenario"
                    yKeys={[{ key: 'roi', color: '#8B5CF6', name: 'ROI (%)' }]}
                    yAxisFormatter={(value) => `${value}%`}
                    tooltipFormatter={(value) => `${value}%`}
                    height={250}
                  />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="border rounded-md p-3">
                    <h4 className="text-sm font-medium mb-1">Buy Now</h4>
                    <div className="flex items-center text-xs text-muted-foreground mb-1">
                      <span className="mr-1">Risk:</span>
                      <span className={`${
                        investmentTimingData.investmentScenarios.buy.now.riskLevel === "Medium" ? "text-amber-500" : 
                        investmentTimingData.investmentScenarios.buy.now.riskLevel === "Medium-Low" ? "text-green-500" :
                        "text-red-500"
                      } font-medium`}>
                        {investmentTimingData.investmentScenarios.buy.now.riskLevel}
                      </span>
                    </div>
                    <div className="flex items-center text-xs mb-1">
                      <span className="mr-1 text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{investmentTimingData.investmentScenarios.buy.now.confidenceScore}%</span>
                    </div>
                  </div>
                  
                  <div className="border rounded-md p-3 bg-blue-50 border-blue-200">
                    <h4 className="text-sm font-medium mb-1">Wait 3 Months</h4>
                    <div className="flex items-center text-xs text-muted-foreground mb-1">
                      <span className="mr-1">Risk:</span>
                      <span className={`${
                        investmentTimingData.investmentScenarios.buy.wait3Months.riskLevel === "Medium" ? "text-amber-500" : 
                        investmentTimingData.investmentScenarios.buy.wait3Months.riskLevel === "Medium-Low" ? "text-green-500" :
                        "text-red-500"
                      } font-medium`}>
                        {investmentTimingData.investmentScenarios.buy.wait3Months.riskLevel}
                      </span>
                    </div>
                    <div className="flex items-center text-xs mb-1">
                      <span className="mr-1 text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{investmentTimingData.investmentScenarios.buy.wait3Months.confidenceScore}%</span>
                    </div>
                  </div>
                  
                  <div className="border rounded-md p-3">
                    <h4 className="text-sm font-medium mb-1">Wait 6 Months</h4>
                    <div className="flex items-center text-xs text-muted-foreground mb-1">
                      <span className="mr-1">Risk:</span>
                      <span className={`${
                        investmentTimingData.investmentScenarios.buy.wait6Months.riskLevel === "Medium" ? "text-amber-500" : 
                        investmentTimingData.investmentScenarios.buy.wait6Months.riskLevel === "Medium-Low" ? "text-green-500" :
                        "text-red-500"
                      } font-medium`}>
                        {investmentTimingData.investmentScenarios.buy.wait6Months.riskLevel}
                      </span>
                    </div>
                    <div className="flex items-center text-xs mb-1">
                      <span className="mr-1 text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{investmentTimingData.investmentScenarios.buy.wait6Months.confidenceScore}%</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {investmentGoal === 'sell' && (
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium text-sm">Projected Profit for Sell Scenarios</h3>
                  <BarChart
                    title=""
                    data={[
                      { scenario: 'Sell Now', profit: investmentTimingData.investmentScenarios.sell.now.profit },
                      { scenario: 'Wait 3 Months', profit: investmentTimingData.investmentScenarios.sell.wait3Months.profit },
                      { scenario: 'Wait 6 Months', profit: investmentTimingData.investmentScenarios.sell.wait6Months.profit }
                    ]}
                    xKey="scenario"
                    yKeys={[{ key: 'profit', color: '#10B981', name: 'Profit ($)' }]}
                    yAxisFormatter={(value) => `$${value/1000}k`}
                    tooltipFormatter={(value) => `$${value.toLocaleString()}`}
                    height={250}
                  />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="border rounded-md p-3">
                    <h4 className="text-sm font-medium mb-1">Sell Now</h4>
                    <div className="flex items-center text-xs text-muted-foreground mb-1">
                      <span className="mr-1">Timing:</span>
                      <span className="font-medium">
                        {investmentTimingData.investmentScenarios.sell.now.marketTiming}
                      </span>
                    </div>
                    <div className="flex items-center text-xs mb-1">
                      <span className="mr-1 text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{investmentTimingData.investmentScenarios.sell.now.confidenceScore}%</span>
                    </div>
                  </div>
                  
                  <div className="border rounded-md p-3">
                    <h4 className="text-sm font-medium mb-1">Wait 3 Months</h4>
                    <div className="flex items-center text-xs text-muted-foreground mb-1">
                      <span className="mr-1">Timing:</span>
                      <span className="font-medium">
                        {investmentTimingData.investmentScenarios.sell.wait3Months.marketTiming}
                      </span>
                    </div>
                    <div className="flex items-center text-xs mb-1">
                      <span className="mr-1 text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{investmentTimingData.investmentScenarios.sell.wait3Months.confidenceScore}%</span>
                    </div>
                  </div>
                  
                  <div className="border rounded-md p-3 bg-green-50 border-green-200">
                    <h4 className="text-sm font-medium mb-1">Wait 6 Months</h4>
                    <div className="flex items-center text-xs text-muted-foreground mb-1">
                      <span className="mr-1">Timing:</span>
                      <span className="font-medium">
                        {investmentTimingData.investmentScenarios.sell.wait6Months.marketTiming}
                      </span>
                    </div>
                    <div className="flex items-center text-xs mb-1">
                      <span className="mr-1 text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{investmentTimingData.investmentScenarios.sell.wait6Months.confidenceScore}%</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">AI Recommendation</CardTitle>
            <Clock className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center py-4">
              <div className="w-24 h-24 rounded-full bg-blue-50 flex items-center justify-center mb-4">
                <CalendarDays className="h-12 w-12 text-blue-500" />
              </div>
              
              <div className="text-center mb-6">
                <h3 className="text-lg font-bold mb-1">{investmentTimingData.recommendation}</h3>
                <p className="text-sm text-muted-foreground">for optimal outcome</p>
              </div>
              
              <div className="w-full space-y-4">
                <div className="p-3 border rounded-md flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium">Interest Rate Changes</h4>
                    <p className="text-xs text-muted-foreground">
                      Interest rates projected to decrease by 0.5% in the next quarter.
                    </p>
                  </div>
                </div>
                
                <div className="p-3 border rounded-md flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium">Seasonal Factors</h4>
                    <p className="text-xs text-muted-foreground">
                      Market activity expected to increase in spring months.
                    </p>
                  </div>
                </div>
                
                <Button className="w-full mt-4" variant="outline">
                  Download Full Analysis Report
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InvestmentTiming;
