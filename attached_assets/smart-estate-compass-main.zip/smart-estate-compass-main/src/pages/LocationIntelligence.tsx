
import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { locationData } from '@/data/mockData';
import 'leaflet/dist/leaflet.css';
import { MapPin, School, Building, Leaf, BarChart3 } from 'lucide-react';

const LocationIntelligence = () => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  
  useEffect(() => {
    // This is a hack to make sure leaflet loads properly with SSR frameworks
    if (typeof window !== 'undefined' && !mapLoaded && mapContainerRef.current) {
      import('leaflet').then((L) => {
        const map = L.map(mapContainerRef.current!).setView(
          [locationData.coordinates.lat, locationData.coordinates.lng],
          14
        );

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Add marker for main property location
        L.marker([locationData.coordinates.lat, locationData.coordinates.lng])
          .addTo(map)
          .bindPopup(locationData.address)
          .openPopup();

        // Add school markers
        locationData.nearbyFacilities.schools.forEach(school => {
          // Calculate rough latitude/longitude based on distance (this is just for demo)
          const lat = locationData.coordinates.lat + (Math.random() * 0.01 - 0.005);
          const lng = locationData.coordinates.lng + (Math.random() * 0.01 - 0.005);
          
          L.marker([lat, lng], {
            icon: L.divIcon({
              className: 'custom-div-icon',
              html: `<div style="background-color: rgba(59, 130, 246, 0.8); width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: white; font-weight: bold;">S</div>`,
              iconSize: [30, 30],
              iconAnchor: [15, 15]
            })
          })
            .addTo(map)
            .bindPopup(`<b>${school.name}</b><br>Rating: ${school.rating}/10<br>Distance: ${school.distance} miles`);
        });

        // Add hospital markers
        locationData.nearbyFacilities.hospitals.forEach(hospital => {
          const lat = locationData.coordinates.lat + (Math.random() * 0.01 - 0.005);
          const lng = locationData.coordinates.lng + (Math.random() * 0.01 - 0.005);
          
          L.marker([lat, lng], {
            icon: L.divIcon({
              className: 'custom-div-icon',
              html: `<div style="background-color: rgba(239, 68, 68, 0.8); width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: white; font-weight: bold;">H</div>`,
              iconSize: [30, 30],
              iconAnchor: [15, 15]
            })
          })
            .addTo(map)
            .bindPopup(`<b>${hospital.name}</b><br>Rating: ${hospital.rating}/5<br>Distance: ${hospital.distance} miles`);
        });

        // Add park markers
        locationData.nearbyFacilities.parks.forEach(park => {
          const lat = locationData.coordinates.lat + (Math.random() * 0.01 - 0.005);
          const lng = locationData.coordinates.lng + (Math.random() * 0.01 - 0.005);
          
          L.marker([lat, lng], {
            icon: L.divIcon({
              className: 'custom-div-icon',
              html: `<div style="background-color: rgba(16, 185, 129, 0.8); width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: white; font-weight: bold;">P</div>`,
              iconSize: [30, 30],
              iconAnchor: [15, 15]
            })
          })
            .addTo(map)
            .bindPopup(`<b>${park.name}</b><br>Size: ${park.size}<br>Distance: ${park.distance} miles`);
        });

        // Add heatmap-like circle for overall score visualization
        L.circle([locationData.coordinates.lat, locationData.coordinates.lng], {
          color: 'rgba(79, 70, 229, 0.2)',
          fillColor: 'rgba(79, 70, 229, 0.1)',
          fillOpacity: 0.5,
          radius: 800
        }).addTo(map);

        setMapLoaded(true);

        return () => {
          map.remove();
        };
      });
    }
  }, [mapLoaded]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Location Intelligence</h1>
        <p className="text-muted-foreground mt-2">
          Analyze location quality based on amenities, services, and neighborhood characteristics.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Location Map</CardTitle>
          </CardHeader>
          <CardContent className="p-0 aspect-[16/9] overflow-hidden rounded-b-lg">
            <div ref={mapContainerRef} className="h-full w-full" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Location Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Address</span>
                <span className="text-sm">{locationData.address}</span>
              </div>

              <div className="flex flex-col">
                <span className="text-sm font-medium mb-2">Overall Score</span>
                <div className="w-full bg-muted rounded-full h-4">
                  <div 
                    className="bg-primary h-4 rounded-full text-xs text-white flex items-center justify-center" 
                    style={{ width: `${locationData.locationScores.overall}%` }}
                  >
                    {locationData.locationScores.overall}/100
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">Education</span>
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-sm font-semibold">{locationData.locationScores.education}</span>
                    <span className="text-xs text-muted-foreground">/100</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div 
                      className="bg-blue-500 h-1.5 rounded-full" 
                      style={{ width: `${locationData.locationScores.education}%` }}
                    ></div>
                  </div>
                </div>

                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">Healthcare</span>
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-sm font-semibold">{locationData.locationScores.healthcare}</span>
                    <span className="text-xs text-muted-foreground">/100</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div 
                      className="bg-red-500 h-1.5 rounded-full" 
                      style={{ width: `${locationData.locationScores.healthcare}%` }}
                    ></div>
                  </div>
                </div>

                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">Transportation</span>
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-sm font-semibold">{locationData.locationScores.transportation}</span>
                    <span className="text-xs text-muted-foreground">/100</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div 
                      className="bg-amber-500 h-1.5 rounded-full" 
                      style={{ width: `${locationData.locationScores.transportation}%` }}
                    ></div>
                  </div>
                </div>

                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">Safety</span>
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-sm font-semibold">{locationData.locationScores.safety}</span>
                    <span className="text-xs text-muted-foreground">/100</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div 
                      className="bg-green-500 h-1.5 rounded-full" 
                      style={{ width: `${locationData.locationScores.safety}%` }}
                    ></div>
                  </div>
                </div>

                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">Amenities</span>
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-sm font-semibold">{locationData.locationScores.amenities}</span>
                    <span className="text-xs text-muted-foreground">/100</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div 
                      className="bg-purple-500 h-1.5 rounded-full" 
                      style={{ width: `${locationData.locationScores.amenities}%` }}
                    ></div>
                  </div>
                </div>

                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">Environment</span>
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-sm font-semibold">{locationData.locationScores.environment}</span>
                    <span className="text-xs text-muted-foreground">/100</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5">
                    <div 
                      className="bg-emerald-500 h-1.5 rounded-full" 
                      style={{ width: `${locationData.locationScores.environment}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-sm font-medium">Crime Rate</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm">{locationData.crimeRate.value}</span>
                  <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 rounded-full">{locationData.crimeRate.trend}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <School className="h-5 w-5 text-blue-500" />
              Education
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {locationData.nearbyFacilities.schools.map((school, index) => (
                <div key={index} className="flex justify-between items-center p-2 border-b last:border-b-0">
                  <div>
                    <h4 className="text-sm font-medium">{school.name}</h4>
                    <p className="text-xs text-muted-foreground">{school.distance} miles away</p>
                  </div>
                  <div className="bg-blue-50 text-blue-700 rounded-full px-2 py-1 text-xs font-medium">
                    {school.rating}/10
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <Building className="h-5 w-5 text-red-500" />
              Healthcare
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {locationData.nearbyFacilities.hospitals.map((hospital, index) => (
                <div key={index} className="flex justify-between items-center p-2 border-b last:border-b-0">
                  <div>
                    <h4 className="text-sm font-medium">{hospital.name}</h4>
                    <p className="text-xs text-muted-foreground">{hospital.distance} miles away</p>
                  </div>
                  <div className="bg-red-50 text-red-700 rounded-full px-2 py-1 text-xs font-medium">
                    {hospital.rating}/5
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <Leaf className="h-5 w-5 text-green-500" />
              Greenery
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {locationData.nearbyFacilities.parks.map((park, index) => (
                <div key={index} className="flex justify-between items-center p-2 border-b last:border-b-0">
                  <div>
                    <h4 className="text-sm font-medium">{park.name}</h4>
                    <p className="text-xs text-muted-foreground">{park.distance} miles away</p>
                  </div>
                  <div className="bg-green-50 text-green-700 rounded-full px-2 py-1 text-xs font-medium">
                    {park.size}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            AI Location Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm">
              Based on comprehensive data analysis of 32 factors, this location offers excellent value for residential investment. The area is experiencing steady growth with improving amenities, while maintaining a family-friendly atmosphere.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-3 border rounded-md">
                <h4 className="text-sm font-semibold">Growth Potential</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  The area is projected to see 12% property value growth over the next 5 years.
                </p>
              </div>
              
              <div className="p-3 border rounded-md">
                <h4 className="text-sm font-semibold">Development Plans</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  New shopping center and expanded public transportation planned within 2 miles.
                </p>
              </div>
              
              <div className="p-3 border rounded-md">
                <h4 className="text-sm font-semibold">Demographics</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Growing population of young professionals and young families in the area.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LocationIntelligence;
