
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import LineChart from '@/components/charts/LineChart';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { propertyPriceData, propertyTypes, cities } from '@/data/mockData';
import { ArrowRight, CheckCircle, AlertTriangle, TrendingUp, AlertCircle } from 'lucide-react';

const PriceForecasting = () => {
  const [city, setCity] = useState(cities[0]);
  const [propertyType, setPropertyType] = useState(propertyTypes[0]);
  const [formSubmitted, setFormSubmitted] = useState(false);

  // Combine historical and forecast data for charting
  const combinedPriceData = [
    ...propertyPriceData.historicalPrices,
    ...propertyPriceData.forecastPrices.slice(1) // Skip the overlapping year
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  const getMarketStatusColor = () => {
    switch(propertyPriceData.marketAssessment) {
      case "Undervalued":
        return "text-green-500";
      case "Overvalued":
        return "text-red-500";
      case "Slightly Overvalued":
        return "text-amber-500";
      case "Slightly Undervalued":
        return "text-blue-500";
      default:
        return "text-gray-500";
    }
  };

  const getMarketStatusIcon = () => {
    switch(propertyPriceData.marketAssessment) {
      case "Undervalued":
      case "Slightly Undervalued":
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case "Overvalued":
      case "Slightly Overvalued":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      default:
        return <TrendingUp className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Land & Property Price Forecasting</h1>
        <p className="text-muted-foreground mt-2">
          Analyze historical prices and get AI-generated forecasts for specific locations and property types.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-medium">Property Details</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Select value={city} onValueChange={setCity}>
                  <SelectTrigger id="location" className="w-full">
                    <SelectValue placeholder="Select a location" />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map((city) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="property-type">Property Type</Label>
                <Select value={propertyType} onValueChange={setPropertyType}>
                  <SelectTrigger id="property-type" className="w-full">
                    <SelectValue placeholder="Select property type" />
                  </SelectTrigger>
                  <SelectContent>
                    {propertyTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="property-size">Square Footage</Label>
                <Input id="property-size" placeholder="Enter square footage" type="number" defaultValue="1500" min="100" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bedrooms">Bedrooms</Label>
                <Input id="bedrooms" placeholder="Number of bedrooms" type="number" defaultValue="3" min="0" />
              </div>
            </div>

            <div className="flex justify-end">
              <Button type="submit" className="flex items-center gap-2">
                Generate Forecast
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {formSubmitted && (
        <>
          <div className="grid gap-6 grid-cols-1 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Price Forecast (2023-2027)</CardTitle>
              </CardHeader>
              <CardContent>
                <LineChart
                  title=""
                  data={combinedPriceData}
                  xKey="year"
                  yKeys={[{ key: 'price', color: '#8B5CF6', name: 'Property Price' }]}
                  yAxisFormatter={(value) => `$${value / 1000}k`}
                  tooltipFormatter={(value) => `$${value.toLocaleString()}`}
                  height={350}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Market Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex flex-col items-center p-4 border rounded-md bg-muted/30">
                    {getMarketStatusIcon()}
                    <h3 className={`text-lg font-semibold mt-2 ${getMarketStatusColor()}`}>
                      {propertyPriceData.marketAssessment}
                    </h3>
                    <p className="text-sm text-center text-muted-foreground mt-1">
                      Based on comparable properties and economic indicators
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium">Current Price/sqft</span>
                        <span className="text-sm font-semibold">${propertyPriceData.pricePerSqft.current}</span>
                      </div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium">City Average</span>
                        <span className="text-sm font-semibold">${propertyPriceData.pricePerSqft.cityAverage}</span>
                      </div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium">Predicted in 12 months</span>
                        <span className="text-sm font-semibold">${propertyPriceData.pricePerSqft.predicted}</span>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium">5-Year Growth Potential</span>
                        <span className="text-sm font-semibold text-green-500">+18.9%</span>
                      </div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium">Investment Potential</span>
                        <span className="text-sm font-semibold">{propertyPriceData.investmentPotential}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-amber-500" />
                Risk Factors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 grid-cols-1 md:grid-cols-3">
                <div className="p-4 border rounded-md">
                  <h3 className="font-semibold mb-2">Market Volatility</h3>
                  <p className="text-sm text-muted-foreground">
                    Medium-term economic uncertainty could affect price stability in this area.
                  </p>
                </div>
                <div className="p-4 border rounded-md">
                  <h3 className="font-semibold mb-2">Supply Constraints</h3>
                  <p className="text-sm text-muted-foreground">
                    Limited new construction in this area may sustain higher prices.
                  </p>
                </div>
                <div className="p-4 border rounded-md">
                  <h3 className="font-semibold mb-2">Interest Rate Sensitivity</h3>
                  <p className="text-sm text-muted-foreground">
                    Property values in this region are historically sensitive to interest rate changes.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};

export default PriceForecasting;
